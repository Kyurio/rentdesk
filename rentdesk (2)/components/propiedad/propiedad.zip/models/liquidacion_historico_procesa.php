
<?php
session_start();
include("../../../includes/sql_inyection.php");
include("../../../configuration.php");
include("../../../includes/funciones.php");
include("../../../includes/services_util.php");
$config        = new Config;
$services   = new ServicesRestful;
$url_services = $config->url_services;
@$inicio        = $_POST["start"];
@$num_reg        = $_POST["length"];
@$num_reg_principal        = $_POST["length"];

$draw            = @$_POST["draw"];
$inicio            = @$_POST["start"];
@$fin            = @$_POST["length"];
$busqueda         = @$_POST["search"]["value"];

$cantidad_filtrados = 0;
$cantidad_registros = 0;


$orden         = "";
if (!empty($_POST["order"][0]["column"]))
	$orden         = @$_POST["order"][0]["column"];

$direccion = "";
if (!empty($_POST["order"][0]["dir"]))
	$direccion = @$_POST["order"][0]["dir"];


$id_company = $_SESSION["rd_company_id"];
$id_usuario = $_SESSION["rd_usuario_id"];


$coma = 0;
$signo_coma = "";
$datos        = "";

if ($inicio == "") {
	$inicio = 0;
}
if ($num_reg == "") {
	$num_reg = 99999;
}

$cant_rows = $num_reg;

$fecha_inicio = $_POST["fecha_inicio"];
$fecha_inicio = $fecha_inicio." 00:00:00";
$fecha_termino = $_POST["fecha_fin"];
$fecha_termino = $fecha_termino." 23:59:59";
// if (isset($_GET["idFicha"])) {
//     $idFicha = $_GET["idFicha"];
$queryCheques = " SELECT pl.id, pl.id_ficha_propiedad, pl.id_ficha_arriendo, direccion, numero, pl.fecha_liquidacion, url_liquidacion, comuna,region
from propiedades.propiedad_liquidaciones pl 
inner join propiedades.vis_propiedades vp 
on vp.id_propiedad = pl.id_ficha_propiedad 
inner join propiedades.ficha_arriendo fa 
on fa.id = pl.id_ficha_arriendo 
where pl.fecha_liquidacion >= '$fecha_inicio'
AND pl.fecha_liquidacion <= '$fecha_termino'
order by pl.id desc ";
// }

// var_dump("QUERY HISTORIAL: ", $queryCheques);



$num_pagina = round($inicio / $cant_rows) + 1;
$data = array("consulta" => $queryCheques, "cantRegistros" => $cant_rows, "numPagina" => $num_pagina);
$resultado = $services->sendPostNoToken($url_services . '/util/paginacion', $data, []);
/*
$resultado = '[
    {
        "propiedad": "ALTOS DEL PARQUE NORTE # 8168 (GOLD+SEGURO), Peñalolén, Región Metropolitana",
        "propietario": "LUIS FREDY CALBUN MIRANDA",
        "monto_a_liquidar": "1180344"
    },
    {
        "propiedad": "CARMEN # 557 Departamento 1211 (SEGURO), Santiago, Región Metropolitana",
        "propietario": "SALOMON BERNABE ACUÑA CIFUENTES",
        "monto_a_liquidar": "231828"
    },
    {
        "propiedad": "HUERFANOS # 786 Local Comercial 29 (fecha pago los 25), Santiago, Región Metropolitana",
        "propietario": "PATRICIO GUILLERMO COFRE DONOSO",
        "monto_a_liquidar": "502767"
    },
    {
        "propiedad": "JOSE DIEGO BENAVENTE # 219 (PAGA LOS DIAS 20), Ñuñoa, Región Metropolitana",
        "propietario": "JOSEFINA URZUA VIDAL",
        "monto_a_liquidar": "721662"
    },
    {
        "propiedad": "PJE AÑORANZA 564, Las Condes, Región Metropolitana",
        "propietario": "JAVIER IGNACIO TOHA RIVEROS",
        "monto_a_liquidar": "666550"
    }
]
';
*/
$objPropLiqGenMasiva = json_decode($resultado);


// echo json_encode($objPropLiqGenMasiva);


$dataCount = array("consulta" => $queryCheques);
$resultadoCount = $services->sendPostNoToken($url_services . '/util/count', $dataCount);
$cantidad_registros = $resultadoCount;

if ($cantidad_registros  != 0) {

	foreach ($objPropLiqGenMasiva as $result) {
		if ($coma == 1)
			$signo_coma = ",";

		$coma = 1;

    $queryPropietario = "   select nombre_1, nombre_2, nombre_3  from propiedades.propiedad_copropietarios pc 
    inner join propiedades.vis_propietarios vp on pc.id_propietario  = vp.id 
    where pc.nivel_propietario = 1 and id_propiedad = ".$result->id_ficha_propiedad." and habilitado  = true";
   
    $data = array("consulta" => $queryPropietario, "cantRegistros" => 1, "numPagina" => 1);
		$resultadoPropietario = $services->sendPostNoToken($url_services . '/util/paginacion', $data, []);
    $objPropietario = json_decode($resultadoPropietario);
    $propietario ="";
    foreach ($objPropietario as $resultPropietario) {
    $propietario =$propietario. $resultPropietario->nombre_1 . "<br>" . $resultPropietario->nombre_2 . "<br>" . $resultPropietario->nombre_3;
    }
	$propiedad = $result->direccion." #".$result->numero." ".$result->comuna." ".$result->region;
    $codigo_propiedad = $result->id_ficha_propiedad;
    $codigo_arriendo = $result->id_ficha_arriendo;
    $fecha_liquidacion = $result->fecha_liquidacion;
    $url_liquidacion = $result->url_liquidacion;
    $id_liquidacion = $result->id;
		$datos = $datos . "
     $signo_coma
     [
     \"$id_liquidacion\",
      \"$codigo_propiedad\",
      \"$codigo_arriendo\",
      \"$propiedad\",
      \"$propietario\",
      \"$fecha_liquidacion\",
      \"$url_liquidacion\"
      
      
    ]";
	}

	echo "
{
  \"draw\": 1,
  \"recordsTotal\": $cantidad_registros,
  \"recordsFiltered\": $cantidad_registros,
  \"data\": [
    $datos
  ]
}";
} else {
	echo "
{
  \"draw\": 0,
  \"recordsTotal\": 0,
  \"recordsFiltered\": 0,
  \"data\": [
    $datos
  ]
}";
}
