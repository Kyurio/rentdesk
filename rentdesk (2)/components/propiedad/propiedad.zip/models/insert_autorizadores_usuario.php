<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


session_start();



include("../../../includes/sql_inyection.php");
include("../../../configuration.php");
include("../../../includes/funciones.php");
include("../../../includes/services_util.php");
include("../../../includes/envia_email.php");

$config = new Config;
$services = new ServicesRestful;
$url_services = $config->url_services;

$id_company = $_SESSION["rd_company_id"];
$id_usuario = $_SESSION["rd_usuario_id"];

// Set timezone and get the current date and time
date_default_timezone_set("America/Santiago");
$dateTime = new DateTime();
$dateTimeString = $dateTime->format('Y-m-d H:i:s'); // Full date and time string

// Obtener el objeto de sesión y convertirlo en un objeto PHP
$sesion_rd_login = unserialize($_SESSION['sesion_rd_login']);
$correo = $sesion_rd_login->correo;

// 1. Obtener Autorizadores
$queryAutorizadores = "SELECT *
    FROM propiedades.cuenta_usuario
    WHERE id_empresa = $id_company 
    AND autorizador = true 
    AND habilitado = true";

$num_pagina =  round(1 / 9999) + 1;
$dataAutorizadores = array("consulta" => $queryAutorizadores, "cantRegistros" => 99999, "numPagina" => $num_pagina);
$resultadoAutorizadores = $services->sendPostNoToken($url_services . '/util/paginacion', $dataAutorizadores, []);
$usuariosAutorizadores = json_decode($resultadoAutorizadores, true);

if (empty($usuariosAutorizadores)) {
    echo "Autorizadores no encontrados";
    exit;
}

// 2. Obtener usuario por correo (usuario sesión actual)
$queryUsuario = "SELECT *
    FROM propiedades.cuenta_usuario
    WHERE id_empresa = $id_company  AND UPPER(correo) = UPPER('$correo')";

$data = array("consulta" => $queryUsuario, "cantRegistros" => 99999, "numPagina" => $num_pagina);
$resultado = $services->sendPostNoToken($url_services . '/util/paginacion', $data, []);

$objUsuario = json_decode($resultado, true)[0];


if (!$objUsuario) {
    echo "Usuario no encontrado";
    exit;
}

// 3. Obtener autorizadores ya asociados al usuario
$queryHistorial = "SELECT *
    FROM propiedades.historial_autorizadores
    WHERE id_usuario = {$objUsuario['id']}";

$dataHistorial = array("consulta" => $queryHistorial, "cantRegistros" => 99999, "numPagina" => $num_pagina);
$resultadoHistorial = $services->sendPostNoToken($url_services . '/util/paginacion', $dataHistorial, []);
$historialAutorizadores = json_decode($resultadoHistorial, true);

// 4. Mapeo de autorizadores existentes
$autorizadoresMap = [];
foreach ($historialAutorizadores as $hist) {
    $autorizadoresMap[$hist['id_usuario_autorizador']] = $hist;
}

foreach ($usuariosAutorizadores as $usuarioAut) {
    
    $idUsuario = $objUsuario['id'];
    $idUsuarioAutorizador = $usuarioAut['id'];
    $codigoAutorizacionUsuario = generarCodigoAutorizacionUsuario();

    if (isset($autorizadoresMap[$idUsuarioAutorizador])) {
        $hist = $autorizadoresMap[$idUsuarioAutorizador];
        $fechaCreacionCodigo = new DateTime($hist['fecha_creacion_codigo']);
        $interval = $fechaCreacionCodigo->diff($dateTime);

        //if ($interval->h >= 4 || $interval->days > 0) {
            // Update codigo_autorizacion and fecha_codigo_creacion if older than 4 hours
            $queryUpdateHistorialAutorizador = "UPDATE propiedades.historial_autorizadores
                SET codigo_autorizacion = '$codigoAutorizacionUsuario', fecha_creacion_codigo = '$dateTimeString'
                WHERE id_usuario = $idUsuario AND id_usuario_autorizador = $idUsuarioAutorizador";

            $dataUpdate = array("consulta" => $queryUpdateHistorialAutorizador);
            $resultadoUpdate = $services->sendPostDirecto($url_services . '/util/dml', $dataUpdate);
            
        
            if (!$resultadoUpdate) {
                echo "Error al actualizar historial autorizador para usuario $idUsuario";
                exit;
            }
        //}
    } else {
        // Insert new autorizadores into historial_autorizadores
        $queryInsertHistorialAutorizador = "INSERT INTO propiedades.historial_autorizadores
            (id_usuario, id_usuario_autorizador, codigo_autorizacion, fecha_creacion_codigo)
            VALUES($idUsuario, $idUsuarioAutorizador, '$codigoAutorizacionUsuario', '$dateTimeString')";

        $dataInsert = array("consulta" => $queryInsertHistorialAutorizador);
        $resultadoInsert = $services->sendPostDirecto($url_services . '/util/dml', $dataInsert);

        if (!$resultadoInsert) {
            echo "Error al insertar historial autorizador para usuario $idUsuario";
            exit;
        }
    }
}

// Obtener Autorizadores de usuario actualizados
$queryAutorizadores = "SELECT au.*, cu.nombres as nombre_autorizador, cu.correo as correo_autorizador
    FROM propiedades.historial_autorizadores au, propiedades.cuenta_usuario cu 
    WHERE au.id_usuario = {$objUsuario['id']}
    and cu.id = au.id_usuario_autorizador
    and cu.habilitado = true";

$num_pagina =  round(1 / 9999) + 1;
$dataAutorizadores = array("consulta" => $queryAutorizadores, "cantRegistros" => 99999, "numPagina" => $num_pagina);
$resultadoAutorizadores = $services->sendPostNoToken($url_services . '/util/paginacion', $dataAutorizadores, []);
$usuariosAutorizadores = json_decode($resultadoAutorizadores, true);


foreach ($usuariosAutorizadores as $usuarioAut) {

    $mensaje =  "Estimado usuario: ".$objUsuario['nombres']." ". $objUsuario['apellido_paterno'] ." su codigo es: ".$usuarioAut['codigo_autorizacion'];
    // Parametros a enviar a función de correo   
    envia_mail('Sistema Rentdesk', $objUsuario['nombres'], 'jose.naoi@hotmail.com', 'Petición de Autorización', $mensaje, 3, 'logo_fuenzalida_propiedades.png');
}

return true;
