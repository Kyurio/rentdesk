<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

function GetValores($id)
{
    // Configuración de la conexión
    $host = 'localhost';
    $port = '5431';
    $dbname = 'postgres';
    $user = 'arpis';
    $password = 'arpis';

    try {
        // Conexión a la base de datos
        $conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

        // Verificar la conexión
        if (!$conn) {
            die(json_encode(['status' => 'error', 'message' => 'Error en la conexión: ' . pg_last_error()]));
        }
        
        $checkQuery = "SELECT propiedades.fn_saldos_propietario($id, 0)";
        $checkResult = pg_query($conn, $checkQuery);
        if (!$checkResult) {
            die(json_encode(['status' => 'error', 'message' => 'Error en la consulta: ' . pg_last_error($conn)]));
        }

        // Procesar el resultado de la segunda consulta
        $saldosArray = pg_fetch_all($checkResult);
        
        // Devolver ambos resultados como JSON
        return json_encode(['status' => 'success', 'data' => $saldosArray]); 

    } catch (\Throwable $th) {
        echo json_encode(['status' => 'error', 'message' => $th->getMessage()]);
    } finally {
        // Cerrar la conexión
        if (isset($conn)) {
            pg_close($conn);
        }
    }
}

$id = $_GET['id'];
echo GetValores(id: $id);
