<script>loadPack();</script>    
<h2>Packs de Productos</h2>
<a href="index.php?component=pack&amp;view=pack"><i class="fa fa-fw fa-users-cog  icon-add" aria-hidden="true"></i> <span style="font-size:14px; padding-bottom:8px;">Agregar un nuevo pack</span></a>
              

       <div class="herramientas">
		<button type="button" class="btn btn-default btn-sm recargar" onClick="document.location.reload();">
          <i class="fas fa-search"></i> Recargar Datos
        </button>
        </div>
        
<table id="tabla" class="display" cellspacing="0" width="100%">


        <thead>
            <tr>
				<th>Id.</th>
                <th>Nombre</th>
				<th>Activo</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>
        </thead>
      
    </table>