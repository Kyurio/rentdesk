<script> </script>
<div id="header" style="margin-top:67px">

</div>
<div class="content content-page" >
	<h2>Cargas Masivas</h2>

	<table id="tabla" class="display dataTable no-footer" role="grid" aria-describedby="tabla_info" style="width: 100%; margin-top:15px;" width="100%" cellspacing="0">

		<thead>
			<tr role="row">
				<th class=" " tabindex="0" aria-controls="tabla" rowspan="1" colspan="1" style="width: 17px;" aria-sort="ascending" aria-label="Id.: activate to sort column descending">Nombre de la Carga</th>
				<th class=" " tabindex="0" aria-controls="tabla" rowspan="1" colspan="1" style="width: 60px;" aria-label="Tipo Doc.: activate to sort column ascending">Detalle de Carga</th>
			</tr>
		</thead>

		<tbody>
			<?php echo $listado; ?>
		</tbody>

	</table>
</div>