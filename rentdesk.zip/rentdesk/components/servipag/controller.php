<?php
$view = @$_GET["view"];

if ($view == "servipag") {
    include("views/servipag.php");
}


