<?php
include("models/menu_lateral.php");
include("views/menu_lateral.php");
?>