<?php echo  $menuItems;  ?>

<!-- <li class="nav-item dropdown btn-rotate  d-flex">
	<a class="nav-link" href="" id="menuMantenedores" role="button" data-bs-toggle="dropdown" aria-expanded="false" aria-haspopup="false" style="display: flex;
                      align-items: center;
                      gap: 0.3rem;
					  padding:.5rem

                  ">
		<i class="fa-solid fa-gear font-icon-sup"></i>
		<i class="fas fa-chevron-down"></i>

		<p>
			<span class="d-lg-none d-md-block">Mantenedores</span>
		</p>
	</a>
	<div class="dropdown-menu dropdown-menu-right" aria-labelledby="menuMantenedores">
		<?php /*echo  $lista_menu_conf; */ ?>
	</div>
</li> -->