<?php
$view = @$_GET["view"];


if ($view == "cuentas_contable") {

    include("views/cuentas_contable.php");
}




